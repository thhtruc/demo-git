# demo-git
intern-training-midterm2021

## Profile
- Name: **Doan Thi Thanh Truc** *@thhtruc*
- Account: http://github.com/thhtruc
[GitHub](http://github.com)

![GitHub Logo] (https://github.com/thhtruc/demo-git/issues/1#issue-878241939) 

## List
Assignments | Status
------------ | -------------
01 - git | 
02 - vim | 


